Hi Kaustab,

I compiled this program using Discovery Cluster.

Compile using the below commands :

1) mpicc -o q1 q1.c

2) SRUN mpirun -mca btl_base_warn_component_unused 0 ./q1 123456789 

I have also attached the object file (q1) for your reference.

Transcripted and reffered from : http://selkie-macalester.org/csinparallel/modules/MPIProgramming/build/html/calculatePi/Pi.html

Thank You!

