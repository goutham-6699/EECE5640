Hi Kaustab,

I have compiled this program using Discovery Cluster.

Steps to Compile:


for the file q2

mpicc -std=c99 -o q2 q2.c
./q2 ("enter lower and upper bound values with  bin count")


For Method A:

mpicc -o q2_A q2_A.c -lm
./q2_A

For method B:

mpicc -o q2_B q2_B.c -lm
./q2_B

During the change of nodes , do the changes in Script file named Sample.
I have attached the Q2.pdf file as write-up kindly refer to it.

Thank You!
