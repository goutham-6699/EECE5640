#!/bin/bash
#SBATCH --nodes=1
#SBATCH --time=0:30:00
#SBATCH --job-name=Goutham_Job
#SBATCH --mem=1G
#SBATCH --gres=gpu:1
#SBATCH --output=Q1_out
#SBATCH --partition=gpu
./q1 1024
