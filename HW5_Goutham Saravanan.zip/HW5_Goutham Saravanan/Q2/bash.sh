#!/bin/bash
#SBATCH --nodes=1
#SBATCH --time=0:30:00
#SBATCH --job-name=Davis_Job
#SBATCH --mem=1G
#SBATCH --gres=gpu:1
#SBATCH --output=Q2_out
#SBATCH --partition=gpu
./q2
