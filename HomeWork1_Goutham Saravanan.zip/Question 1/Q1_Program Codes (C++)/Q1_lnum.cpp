#include <iostream>
using namespace std;
int main() {    
    float a,b,c;
    a=1,b=5,c=-4;
    if(a>=b&&a>=c)
        cout << "The Large number is" << a;
    if(b>=a&&b>=c)
        cout << "The Large number is" << b;
    if(c>=a&&c>=b)
        cout << "The Large number is" << c;
    return 0;
}