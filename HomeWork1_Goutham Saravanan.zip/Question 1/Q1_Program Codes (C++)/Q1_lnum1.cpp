#include <iostream>
using namespace std;
int main() {
    float a,b,c;
    if((a>=b)&&(a>=c))
        cout << " Big Number is" << a;
    else if ((b>=a) && (b>=c))
        cout << " Big Number is" << b;
    else
        cout << " Big Number is" << c;
    return 0;
}