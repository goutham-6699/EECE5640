#include <iostream>
using namespace std;
int main() {
    int a=0,b=1,c= 0,num=40;
    cout << "Fibonacci Series: " << a<< ", " << b<< ", ";
    c=a+b;
    while(c<=num) {
        cout << c<< ", ";
        a=b;
        b=c;
        c= a+b;
    }
    return 0;
}