#include <iostream>
using namespace std;
int main() {
   int a[4][4]={{1,5,8,7},{2,4,6,8},{3,9,12,17},
                    {5,9,4,48}};
int trans[10][10],r=4,c=4,i,j;
cout << "\nEntered Matrix: " << endl;
for (int i=0;i<r;++i) {
for (int j=0;j<c;++j) {
 cout <<" "<<a[i][j];
 if (j==c-1)
 cout<<endl<< endl;}}
 for (int i=0;i<r;++i)
 for (int j=0;j<c;++j) {
   trans[j][i]=a[i][j];}
cout<<"\nTranspose of Matrix: "<< endl;
   for(int i=0;i<c;++i)
   for(int j=0;j<r;++j) {
  cout<< " " <<trans[i][j];
  if(j == r-1)
  cout<<endl<<endl;}
 return 0;
}