#include <bits/stdc++.h>
using namespace std;
#define N 4
void transpose(int X[][N], int Y[][N])
{
    int i,j;
    for(i=0;i<N;i++)
        for(j=0;j<N;j++)
            Y[i][j]=X[j][i];
}
int main()
{  int X[N][N]={{1,5,8,7},{2,4,6,8},{3,9,12,17},
                    {5,9,4,48}};
  int Y[N][N],i,j;
 transpose(X,Y);
  cout <<"Transpose :\n";
 for (i=0;i<N;i++)
    {
   for (j=0;j<N;j++)
   cout <<" "<<Y[i][j];
  cout <<"\n";
    }
 
    return 0;
}