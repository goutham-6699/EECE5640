Hi,

To whomever is executing these files.
The programs are written c++ v14. and could be executable in any terminal with g++ library installed.

I personally used Northeastern Discovery Cluster for all of my works to experience its super-power to the most.

For each program, the original and the compiler optimized progream were also attached.

Contents:

1st program : lnum
Optimized version : lnum1

2nd program : fibo
Optimized version : fibo1

3rd program : trans
Optimized version : trans1

For your reference I have also attached the screenshot in the seperate file under Q1_Screenshots.

Happy coding with the supercomputers !!!