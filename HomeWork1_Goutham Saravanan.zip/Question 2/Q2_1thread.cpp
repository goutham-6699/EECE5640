// Code transcripted from Tacumo - github


#include <cstdlib> 
#include <ctime> 
#include <iostream> 
#include <vector>
#include <fstream>
using namespace std; 


inline void Swap(int& item1, int& item2);
bool check(vector<int>&,int); //checks the vector for duplicates
void output(vector<int>&,ofstream&);
void Merge(vector<int>&, int, int, int, int);
void MergeSort(vector<int>&, int, int);
void Footer();

int main() 
{     
     srand((unsigned)time(0));
	 vector<int> randomIntegers(5000);
	 ofstream outData;
	 outData.open("output.txt");
	 //Fills the vector with random integers
	 for(vector<int>::iterator i = randomIntegers.begin();i!=randomIntegers.end();
		 ++i)
	 {
		 //Checks for duplicates upon inserting
		 bool inserted = false;
		 while(inserted != true)
		 {
			int num = (rand()%100000+1);
			if (check(randomIntegers,num) != true){
				*i = num;
				inserted = true;
			}
		 }
	 }
	 MergeSort(randomIntegers,0,randomIntegers.size()-1);
	 output(randomIntegers,outData);
	 cout << "Merge Sort complete." << endl;
	 
     return 0;
}



void Merge(vector<int>& values, int leftFirst, int leftLast,
		   int rightFirst, int rightLast)
// Post: values[leftFirst]..values[leftLast] and
//		 values[rightFirst]..values[rightLast] have been merged.
//		 values[leftFirst]..values[rightLast] are now sorted.
{ 
	vector<int> tempVector(5000);
	int index = leftFirst;
	int saveFirst = leftFirst;

	while ((leftFirst <= leftLast) && (rightFirst <= rightLast))
	{
		if (values[leftFirst] < values[rightFirst])
		{
			tempVector[index] = values[leftFirst];
			leftFirst++;
		}
		else
		{
			tempVector[index] = values[rightFirst];
			rightFirst++;
		}
		index++;
	}

	while (leftFirst <= leftLast)
	// Copy remaining items from left half.
	{
		tempVector[index] = values[leftFirst];
		leftFirst++;
		index++;
	}

	while (rightFirst <= rightLast)
	// Copy remaining items from right half.
	{
		tempVector[index] = values[rightFirst];
		rightFirst++;
		index++;
	}

	for (index = saveFirst; index <= rightLast; index++)
		values[index] = tempVector[index];
}

void MergeSort(vector<int>& values, int first, int last)
// Post: The elements in values are sorted by key.
{float t3;
    clock_t t1, t2;
    t1 = clock();
	if (first < last)
	{
		int middle = (first + last) / 2;
		MergeSort(values, first, middle);
		MergeSort(values, middle + 1, last);
		Merge(values, first, middle, middle + 1, last);
	}
	t2 = clock();
t3= t2 - t1 /(double)CLOCKS_PER_SEC;
cout << "Time taken: " << t3<< endl;
	
}


//Post Contents of item1 and item2 have been swapped.
inline void Swap(int& item1, int& item2)
{
	int tempItem;
	tempItem = item1;
	item1 = item2;
	item2 = tempItem;
}


 //Outputs the vector contents to a file
void output (vector<int>& randomIntegers, ofstream& outData)
{
	 for(vector<int>::iterator j = randomIntegers.begin();j!=randomIntegers.end();
		 ++j)
	 {
		 outData << *j << endl;
	 }

}

//Checks vector for duplicates
bool check(vector<int>& randomIntegers, int num)
{
	for(vector<int>::iterator i = randomIntegers.begin();i!=randomIntegers.end();++i)
	{
		if (*i == num)
			return true;
	}
	return false;
}


