Hi,

Instruction and citations for those who refer this material.

The program is about to generate the random 5000 integers from 1 to 100000 using any sorting algorithm.

Here I have picked merge sort to execute my program.

The program is carried out in 4 different threadings namely starting from 1, 2, 4 to 8.

The aim of the question is to measure the execution time taken by each threads.

The output screenshot have been pasted in the Q2 folder for your refernece.


Q2_1thread citated from : Tacumo from github (https://github.com/Tacuma/Sorts/tree/master/(4)Merge-Sort)
Q2_2thread citated from : GeeksforGeeks.com (https://www.geeksforgeeks.org/merge-sort-using-multi-threading/)
Q2_4thread citated from : GeeksforGeeks.com (https://www.geeksforgeeks.org/merge-sort-using-multi-threading/)
Q2_8thread citated from : Geeksforgeeks.com (https://www.geeksforgeeks.org/merge-sort-using-multi-threading/)


Output (Execution Time):

1 thread : 0.003587
2 thread : 0.002558
4 thread : 0.002367
8 thread : 0.002473

Q2.pdf is the write-up in explained way about the question.

Happy coding !!!