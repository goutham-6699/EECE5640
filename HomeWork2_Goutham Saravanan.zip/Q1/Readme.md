Hi Kaustab,

The Dijkstra's dining philosopher code was transcripted from GeeksforGeeks.com

The program was executed in Northeastern's Discovery Cluster and written in C++.

So as Kaeli mentioned. I have choosen three states to describe about the philosopher's status at the table.
The program runs 10 iterations until all philosopher get a chance in a random assigned threads.
The nature of the program is to create a mutex for each action/state of the philosopher namely up and down after and beofre eating that's how it tells the random neighbour thread to execute.

Q1_Dijkstra.cpp is the main code for the question.

Q1_Driverfile.c is the driver program for the subdivision B.
Q1_driver.h is has to compile along with the driver program using // $ gcc -Wall Q1_Driverfile.c Q1_driver.h -o Q1
Using the Object file Q1 again compile with the same command in GNU with Q1_B.c. 

It works as follows. First it calls initialize_v(), which is a procedure that is undefined. It expects a (void *) in return. This pointer will be passed to all procedures as part of the Phil_struct struct, and the user should initialize it however he/she likes.

Next, the driver does a few other things, and finally forks off the philosopher threads (the total number of philosophers is a command line argument). After doing so, the main thread sleeps for ten seconds, and prints out information about how long each philosopher has been blocked, waiting to eat. This is so that you can make some assessment of how good the protocols are at letting philosophers eat.

Q1_A.cpp is for the subdivison a)
Q1_B.c is for the subdivison b)
Q1_C.cpp is for the subdivison c) is the same program from Q1_Dijkstra.cpp

For all sub-division's are cited to https://web.archive.org/web/20131208203319/http://web.eecs.utk.edu/~plank/plank/classes/cs560/560/notes/Dphil/lecture.html


// Q1.pdf is the write-up file.

Thank You !!!!!