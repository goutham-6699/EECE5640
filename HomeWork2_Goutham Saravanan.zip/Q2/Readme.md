Hi Kaustab,

The programs were run on Northeastern Discovery Cluster so you don't need any speaclized library to import.

Just execute the pthread.c file in Unix terminal // gcc pthread.c -o pthread -lpthread and ./pthread.out

prime.c is the simple program to execute to get the multicore timing used on the cpu.

All the files are successfully executed.

Just for your note to every trials for different number of threading, change the global variable value from 4 -> 8 -> 32-> 40.

Rest all set for the a) division.

For openmp (opmp.c) execute using the command // export OMP_NUM_THREADS=4 (Change the thread accordingly)
//gcc -fopenmp opmp.c -o opmp.out

Q2.pdf is the write-up file.
Q2_extra.pdf is for the extension of the question for extra credit.

Citations:
https://stackoverflow.com/questions/44881796/display-the-prime-numbers-using-multi-threading-in-c
https://codereview.stackexchange.com/questions/251200/prime-numbers-with-array-and-openmp-in-c
https://www.cquestions.com/2011/12/c-program-for-prime-numbers-between-1_11.html

Thank You !!!
